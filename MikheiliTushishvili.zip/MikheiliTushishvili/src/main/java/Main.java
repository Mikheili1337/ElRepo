import java.util.Map;

public final class Main {
    public static void main(String[] args) {

//        ProductUtil.createTable();
//        ProductUtil.insert(new Product("Cucumber","ME",2000));
//        ProductUtil.insert(new Product("Cucumber","ME",1020));
//        ProductUtil.getAllProducts()
//                .stream()
//                .forEach(product -> System.out.println(product));

//        ProductUtil.updateProduct(1,"Melon");
//
//        ProductUtil.getAllProducts()
//                .stream()
//                .forEach(product -> System.out.println(product));

//        ProductUtil.deleteProduct(3);
//        ProductUtil.sum(2);
//        ProductUtil.getSameProducts()
//                .stream()
//                .forEach(product -> System.out.println(product));







    }
}

